#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=5
#SBATCH --mem=32g
#SBATCH --time=4-24:00:00
#SBATCH --partition=qTRDGPU
# -p qTRDGPUH,qTRDGPUM
#SBATCH --gres=gpu:RTX:1
#SBATCH --account=psy53c17
#SBATCH -J s50_topk_update
#SBATCH -e ./Jobs/reports/report-%A.err
#SBATCH -o ./Jobs/reports/report-%A.out
#SBATCH --mail-type=ALL
#SBATCH --mail-user=rio.ohib@gmail.com

sleep 5s

export OMP_NUM_THREADS=1
export MODULEPATH=/apps/Compilers/modules-3.2.10/Debug-Build/Modules/3.2.10/modulefiles/
echo $HOSTNAME >&2 

# source /data/users2/bthapaliya/anaconda-main/anaconda3/bin/activate 
source activate signal

DENSE=0.5
SEED=2023
# for SEED in 110 220 550
# do
python main_topk.py --model 'resnet18' \
--dataset 'cifar10' \
--partition_method 'dir' \
--partition_alpha 0.3 \
--batch_size 16 \
--lr 0.1 \
--lr_decay 0.998 \
--epochs 5 \
--dense_ratio $DENSE \
--client_num_in_total 100 --frac 0.1 \
--comm_round 500 \
--seed $SEED \
--exp_name "sps_50_topk" \
--update_topk \
# done 

## old seed: 2022

sleep 30s